import argparse
import nltk
import jieba
import json
import re
import os

def process_en(dataset):
    concepts = set()
    with open('{}/preq.txt'.format(dataset), 'r', encoding='utf-8') as f:
        for line in f.read().split('\n'):
            if line:
                tmp = line.split('\t')
                concepts.add(tmp[0])
                concepts.add(tmp[1])
    concepts = list(concepts)
    concepts.sort()
    with open('{}/concepts.txt'.format(dataset), 'w', encoding='utf-8') as f:
        f.write('\n'.join(concepts))
    mapping = {}
    for c in concepts:
        c2 = ' '.join(nltk.tokenize.word_tokenize(re.sub('\(.*\)', '', c.lower())))
        mapping[c] = c2
    res = []
    with open('{}/captions.txt'.format(dataset), 'r', encoding='utf-8') as f:
        for line in f.read().split('\n'):
            if line:
                v, text = line.split(',')
                text = ' {} '.format(' '.join(nltk.tokenize.word_tokenize(text.lower())))
                t2c = [c for c in concepts if ' {} '.format(mapping[c]) in text]
                res.append({'video': v, 'concepts': t2c})
    with open('{}/video-concepts.json'.format(dataset), 'w', encoding='utf-8') as f:
        f.write('\n'.join([json.dumps(r, ensure_ascii=False) for r in res]))

def process_zh(dataset):
    concepts = set()
    with open('{}/preq.txt'.format(dataset), 'r', encoding='utf-8') as f:
        for line in f.read().split('\n'):
            if line:
                tmp = line.split('\t')
                concepts.add(tmp[0])
                concepts.add(tmp[1])
    concepts = list(concepts)
    concepts.sort()
    with open('{}/concepts.txt'.format(dataset), 'w', encoding='utf-8') as f:
        f.write('\n'.join(concepts))
    res = []
    with open('{}/captions.txt'.format(dataset), 'r', encoding='utf-8') as f:
        for line in f.read().split('\n'):
            if line:
                v, text = line.split(',')
                t2c = [c for c in concepts if c in text]
                res.append({'video': v, 'concepts': t2c})
    with open('{}/video-concepts.json'.format(dataset), 'w', encoding='utf-8') as f:
        f.write('\n'.join([json.dumps(r, ensure_ascii=False) for r in res]))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Preprocess')
    parser.add_argument('-dataset', type=str, required=True)
    parser.add_argument('-lang', type=str, required=True, choices=['en', 'zh'])
    args = parser.parse_args()
    assert os.path.exists(args.dataset)
    if args.lang == 'en':
        process_en(args.dataset)
    if args.lang == 'zh':
        process_zh(args.dataset)